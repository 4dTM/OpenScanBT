import dbus
import keymap
from time import sleep
import evdev
HID_DBUS = 'org.yaptb.btkbservice'
HID_SRVC = '/org/yaptb/btkbservice'

class CameraRemote:
    """
    Send the HID messages to the keyboard D-Bus server for the volume-up button
    """
    def __init__(self):
        self.bus = dbus.SystemBus()
        self.btkobject = self.bus.get_object(HID_DBUS,
                                             HID_SRVC)
        self.btk_service = dbus.Interface(self.btkobject,
                                          HID_DBUS)
    def take_photo(self):
      for k in range (1,50):

                 self.btk_service.send_keys([161, 1, 0, 0 , k, 0, 0, 0, 0, 0])
                 sleep(0.05)
                 self.btk_service.send_keys([161, 1, 0, 0, 0, 0, 0, 0, 0, 0])
                 sleep(0.05)
if __name__ == '__main__':
    cr = CameraRemote()
    cr.take_photo()




